
#include <iostream>
#include <omp.h>
using namespace std;
int main(){
    long N=100000000;
    double *A=new double[N], *B=new double[N], *C=new double[N];
    for(long i=0;i<N;i++) A[i]=B[i]=1.0;
    double start=omp_get_wtime();
    #pragma omp parallel for
    for(long i=0;i<N;i++) C[i]=A[i]+B[i];
    double end=omp_get_wtime();
    cout<<"Time: "<<end-start<<endl;
    delete[] A; delete[] B; delete[] C;
}
