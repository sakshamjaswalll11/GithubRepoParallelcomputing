
// Run exp1 with 1,2,4,8 threads
// Speedup = T1/Tn
// Efficiency = Speedup/Threads
