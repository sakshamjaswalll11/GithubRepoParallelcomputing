
#include <iostream>
#include <omp.h>
using namespace std;
int main(){
    long long steps=100000000;
    double step=1.0/steps,sum=0.0;
    double start=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for(long long i=0;i<steps;i++){
        double x=(i+0.5)*step;
        sum+=4.0/(1.0+x*x);
    }
    double end=omp_get_wtime();
    cout<<"Time: "<<end-start<<endl;
}
