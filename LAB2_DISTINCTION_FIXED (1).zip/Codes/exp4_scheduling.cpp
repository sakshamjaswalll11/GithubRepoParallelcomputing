
#include <iostream>
#include <omp.h>
using namespace std;
int main(){
    int N=1000000;
    double start=omp_get_wtime();
    #pragma omp parallel for schedule(dynamic,10)
    for(int i=0;i<N;i++){
        double x=0;
        for(int j=0;j<1000;j++) x+=j*i;
    }
    double end=omp_get_wtime();
    cout<<"Dynamic Time: "<<end-start<<endl;
}
