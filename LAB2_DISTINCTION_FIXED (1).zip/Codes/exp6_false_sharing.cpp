
#include <iostream>
#include <omp.h>
using namespace std;
#define CACHE 64
struct padded{ long long val; char pad[CACHE-8]; };
int main(){
    padded arr[8];
    double start=omp_get_wtime();
    #pragma omp parallel
    {
        int tid=omp_get_thread_num();
        for(long long i=0;i<100000000;i++)
            arr[tid].val++;
    }
    double end=omp_get_wtime();
    cout<<"False Sharing Time: "<<end-start<<endl;
}
