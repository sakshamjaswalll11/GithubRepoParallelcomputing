
#include <iostream>
#include <omp.h>
using namespace std;
int main(){
    long long N=10000000;
    double sum=0;
    double start=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for(long long i=0;i<N;i++) sum+=1;
    double end=omp_get_wtime();
    cout<<"Reduction Time: "<<end-start<<endl;
}
